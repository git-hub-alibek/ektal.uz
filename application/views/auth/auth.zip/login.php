<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

<div class="row justify-content-center" style="margin-top: 100px;">
  <div class="col-12 col-md-4 ">
    <div id="infoMessage"><?php echo $message;?></div>
    <div class="card border-info mb-3">
      <div class="card-header"><h3><?php echo lang('login_heading');?></h3></div>
      <div class="card-body text-info">
      <?php echo form_open("auth/login");?>

      <p>
        <?php echo lang('login_identity_label', 'identity');?>
        <?php echo form_input($identity);?>
      </p>

      <p>
        <?php echo lang('login_password_label', 'password');?>
        <?php echo form_input($password);?>
      </p>

      <p>
        <?php echo lang('login_remember_label', 'remember');?>
        <?php echo form_checkbox('remember', '1', FALSE, 'id="remember"');?>
      </p>


      <p><?php echo form_submit('submit', lang('login_submit_btn'),'class="btn btn-primary"');?></p>

      <?php echo form_close();?>
      <p><a href="forgot_password"><?php echo lang('login_forgot_password');?></a></p>
      </div>
    </div>
  </div><!-- col -->
</div><!-- row -->